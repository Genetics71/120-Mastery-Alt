export function setup(ctx) {

	// Mastery Spend Menu
	ctx.patch(SpendMasteryMenuItem, 'updateProgress').after(function(result, skill, action, spendAmount) {
        const progress = skill.getMasteryProgress(action);
        this.level.textContent = `${progress.level}`;
        this.progressBar.style.width = `${progress.percent}%`;
		
		const xp = skill.getMasteryXP(action);
		const lvl = exp.xpToLevel(xp);
		this.level.textContent = `${ lvl }`;

		this.level.classList.remove('text-warning', 'text-success');
		this.progressBar.classList.remove('bg-warning', 'bg-success');
		this.progressBar.classList.add('bg-info');
		if (lvl >= 120) {
            this.progressBar.classList.replace("bg-info", "bg-success");
            hideElement(this.levelUpButton);
            hideElement(this.xpRequired);

		} else {
            this.progressBar.classList.replace("bg-success", "bg-info");
            showElement(this.levelUpButton);
            showElement(this.xpRequired);
            const nextLevel = Math.min(progress.level + spendAmount, 120);
            const xpRequired = exp.level_to_xp(nextLevel) - progress.xp + 1;
            const levelIncrease = nextLevel - progress.level;
            this.xpRequired.textContent = templateLangString(
                "MENU_TEXT_SPEND_MASTERY_XP_FOR",
                {
                    xp: numberWithCommas(Math.floor(xpRequired)),
                    num: `${levelIncrease}`,
                }
            );
            this.levelUpButton.textContent = `+${levelIncrease}`;
            this.levelUpButton.onclick = () =>
                skill.levelUpMasteryWithPoolXP(action, levelIncrease);
            const poolTierChange = skill.getPoolBonusChange(-xpRequired);
            if (xpRequired <= skill.masteryPoolXP) {
                if (poolTierChange < 0) {
                    this.levelUpButton.classList.remove(
                        "btn-danger",
                        "btn-success"
                    );
                    this.levelUpButton.classList.add("btn-warning");
                } else {
                    this.levelUpButton.classList.remove(
                        "btn-danger",
                        "btn-warning"
                    );
                    this.levelUpButton.classList.add("btn-success");
                }
                this.levelUpButton.classList.remove("disabled");
                this.levelUpButton.disabled = false;
            } else {
                this.levelUpButton.classList.remove(
                    "btn-success",
                    "btn-warning"
                );
                this.levelUpButton.classList.add("disabled", "btn-danger");
                this.levelUpButton.disabled = true;
            }
        }

	});

	// Normal Mastery Display
	ctx.patch(MasteryDisplay, 'updateValues').after(function(result, progress) {
		const lvl = exp.xpToLevel(progress.xp);
		this.level.textContent = `${ lvl }`;

		this.level.classList.remove('text-warning', 'text-success');
		this.progressBar.classList.remove('bg-warning', 'bg-success');
		this.progressBar.classList.add('bg-info');

		if (lvl >= 99) {
			this.level.classList.add('text-warning');
			this.progressBar.classList.replace('bg-info', 'bg-warning');
		}
		if (lvl >= 120) {
			this.level.classList.replace('text-warning', 'text-success');
			this.progressBar.classList.replace('bg-warning', 'bg-success');
		}
	});

	// Compact Mastery Display
	ctx.patch(CompactMasteryDisplay, 'updateValues').after(function(result, progress) {
		const lvl = exp.xpToLevel(progress.xp);
		this.level.textContent = `${ lvl }`;

		this.level.classList.remove('text-warning', 'text-success');

		if (lvl >= 99) {
			this.level.classList.add('text-warning');
		}
		if (lvl >= 120) {
			this.level.classList.replace('text-warning', 'text-success');
		}
	});

	// Cooking Selection Mastery Display
	ctx.patch(CookingRecipeSelection, 'updateMastery').after(function(result, recipe, cooking) {
		if (recipe.hasMastery) {
			const progress = cooking.getMasteryProgress(recipe);
			const lvl = exp.xpToLevel(progress.xp);
			this.masteryLevel.textContent = `${ lvl }`;

			this.masteryLevel.classList.remove('text-warning', 'text-success');

			if (lvl >= 99) {
				this.masteryLevel.classList.add('text-warning');
			}
			if (lvl >= 120) {
				this.masteryLevel.classList.replace('text-warning', 'text-success');
			}
		}
	});
}
